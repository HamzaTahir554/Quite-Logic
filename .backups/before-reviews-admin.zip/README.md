# Quite Logic

Next.js App Router website built with TypeScript, MUI, React Three Fiber, Three.js, Drei, Framer Motion, and GSAP. The supplied `Demo/` and `snapshots/` references are preserved.

## Development

Requires Node.js 24 and npm.

```powershell
npm.cmd ci
Copy-Item .env.example .env.local
npm.cmd run dev
```

Open http://localhost:3000. On Windows, `npm.cmd` avoids the PowerShell script execution policy restriction.

## Production

```powershell
npm.cmd run build
npm.cmd start
```

Use a host supporting Next.js 16 with Node.js 24, such as Vercel or a Node server. This application includes a server-side contact endpoint and dynamic social images. It is not a static-only export. The first build needs network access to download Manrope through `next/font`; the generated site self-hosts the font.

Before public launch:

- Set `NEXT_PUBLIC_SITE_URL` to the final HTTPS domain before building. It powers canonical URLs, structured data, social metadata, and the sitemap. Development falls back to localhost.
- Set `RESEND_API_KEY`, `CONTACT_FROM_EMAIL` (a verified sender), and `CONTACT_TO_EMAIL` in the hosting secret environment to enable inquiry delivery.
- Configure shared rate limiting at the hosting edge when scaling to multiple instances. The endpoint includes validation, origin checks, payload limits, a honeypot, timeouts, and bounded per-process limits of five inquiries per sender and 60 total per 15 minutes.
- Replace the explicitly labeled illustrative portfolio concepts with authorized client work when available. No customer results or testimonials are fabricated.
- Replace the visibly marked social placeholders with real company profile links.
- Review the privacy information needed for your business before collecting inquiries publicly.

The recipient defaults to `company.quitelogic@gmail.com`; `CONTACT_TO_EMAIL` can override it server-side. Set a valid `RESEND_API_KEY` and `CONTACT_FROM_EMAIL` on a Resend-verified sending domain in `.env.local` or hosting secrets. Gmail is the receiving inbox, not a verified Resend sending domain. Keep credentials out of `.env.example`. Missing configuration returns 503; provider failure returns 502. Failed submissions preserve entered values. Live delivery requires valid credentials and a provider smoke test.

“Book a Meeting” opens the official [Calendly page](https://calendly.com/company-quitelogic/30min) in an accessible modal from the header, contact page, and final CTAs. The iframe loads only when requested, with a direct-link fallback, fixed dimensions, close control, Escape dismissal, and focus restoration. Color parameters follow [Calendly’s documentation](https://calendly.com/help/how-to-customize-your-embed); Calendly controls embedded content and color customization may depend on its plan. No test bookings are created.

## Architecture

- `app/`: homepage, services, about, work/process, portfolio, contact, concept detail pages, SEO endpoints, and branded loading/error/404 states.
- `components/`: shared navigation, footer, page sections, UI, SEO, and dynamically loaded hero scene.
- `data/content.ts`: editable navigation, services, project concepts, and process copy.
- `theme/theme.ts` and `app/globals.css`: brand tokens, MUI customization, layout, motion, and responsive design.
- `lib/contact.ts`: shared form schema and options.
- `app/api/contact/route.ts`: Resend delivery adapter; replace here for another mail provider or CRM.
- `public/logo/`: original supplied branding; `public/projects/`: local concept artwork.

The shared design system uses Smoky Gray `#4B5560` for the page, Slate `#303944` for contrast, Card Gray `#596572` for surfaces, Blue `#2F80FE` for accents, and Off White `#F0F1F8` for primary text. The shared brand component gives Quite and Logic their distinct colors.

The homepage retains its six-faced service cube: Web, Apps, AI Automation, AI Vision, Custom Software, and Explore All. Desktop uses a lazy-loaded React Three Fiber scene with generated local textures, capped DPR, quaternion snapping, scroll selection, raycast face selection, drag, hover, and deliberate autoplay. Tablet/mobile use a lightweight CSS cube with horizontal touch swipes and native vertical scrolling. Accessible buttons and previous/next controls work in both renderers. Reduced motion disables autoplay, WebGL, pointer tilt, and transition animation without hiding service content. Unsupported WebGL and limited device capabilities retain the CSS experience. MUI Drawer provides mobile focus management and Escape dismissal.

`components/motion/` contains sharp scale CTAs, the dot-and-ring cursor, progress/navigation effects, crystal reflections and page-banner treatments. Desktop banner text uses bounded, interpolated translation/rotation; touch and reduced-motion users retain still text. The Services page uses five alternating image/text editorials, matched by filename from `services images/` to `public/services/`, with reserved image space, mask reveals and bounded desktop image movement. Its old cube mount, sculpture markup, scroll controller and unused styles are removed. Three.js/R3F dependencies remain in use on the homepage. How We Work and Philosophy are removed only from Home; their other pages remain intact. Scene rendering and service autoplay pause outside the nearby viewport and in inactive tabs. Continuous decorative motion is scoped to visible sections and pauses in inactive tabs. Animation instances, textures, geometry, listeners, observers, timers, and GSAP contexts have cleanup paths. `app/studio.css` and `app/interaction.css` style the shared pages and interactions; `app/hero.css` implements the centered home hero and branding. `app/atlas-motion.css` styles project visuals, banners, and the Atlas showcase using shared gray tokens. `app/service-cube.css` styles the signature cube, lighter panels, and animated slate footer. Scrolling remains native.

The cube follows the mouse on desktop, including its CSS fallback. Mobile uses passive face rotation, horizontal swipes, and buttons. The site does not access physical motion sensors or request motion permissions. Live reduced-motion preferences stop scene animation and autoplay without a reload.

See [the design system report](qa/DESIGN-SYSTEM-REPORT.md) for the underlying visuals. Capture the signature interaction with `node qa/capture-cube.mjs`; run `node qa/audit-design.mjs` for a short desktop frame/CLS sample. These default to port 3100 and accept `E2E_BASE_URL`. Atlas / Cloud retains its shared illustrative terminal showcase on the homepage, portfolio, and `/portfolio/atlas-cloud` detail page. The previous project URL permanently redirects to the replacement. The earlier [Atlas report](qa/ATLAS-REPORT.md) records that feature's implementation.

## Verification

```powershell
npm.cmd run typecheck
npx.cmd playwright install chromium
npm.cmd run build
npm.cmd run test:e2e
```

Twenty-seven automated tests cover server email payloads/failures and rate limiting, editorial services, crystal banner movement, modal booking, cursor states, the palette, six-face cube, desktop mouse input, mobile touch and native scrolling, absence of sensor access and permission controls, live reduced-motion preferences, Atlas, navigation, portfolio, contact, SEO, banner, branding, and layout checks. All core routes are checked at seven widths (320–1440px). Screenshots are captured in `qa/screenshots/`. A mocked successful contact response tests the UI only, not real email delivery.

For an isolated local test server, run `$env:E2E_BASE_URL='http://localhost:3100'; npm.cmd run test:e2e`. Set the final site origin through `NEXT_PUBLIC_SITE_URL` for deployment; the test server port does not alter canonical configuration.
