import { NextResponse } from "next/server";
import { contactSchema } from "@/lib/contact";
import { contactEmail } from "@/lib/company";
import { allowInquiry } from "@/lib/contact-rate-limit";
import { deliverInquiry } from "@/lib/contact-delivery";
export const runtime = "nodejs";
export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (
    origin &&
    origin !== new URL(request.url).origin &&
    origin !== process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "")
  )
    return NextResponse.json(
      { message: "This request is not allowed." },
      { status: 403 },
    );
  if (!request.headers.get("content-type")?.includes("application/json"))
    return NextResponse.json(
      { message: "Please submit a JSON inquiry." },
      { status: 415 },
    );
  if (Number(request.headers.get("content-length")) > 16000)
    return NextResponse.json(
      { message: "Your inquiry is too large." },
      { status: 413 },
    );
  let data: unknown;
  try {
    const body = await request.text();
    if (body.length > 16000)
      return NextResponse.json(
        { message: "Your inquiry is too large." },
        { status: 413 },
      );
    data = JSON.parse(body);
  } catch {
    return NextResponse.json(
      { message: "Please check your inquiry and try again." },
      { status: 400 },
    );
  }
  const parsed = contactSchema.safeParse(data);
  if (!parsed.success)
    return NextResponse.json(
      { message: "Please check the form fields and try again." },
      { status: 400 },
    );
  const { RESEND_API_KEY, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL } = process.env;
  const limit = allowInquiry(parsed.data.email);
  if (!limit.allowed)
    return NextResponse.json(
      {
        message:
          "Too many inquiries. Please wait a little before trying again, or email us directly.",
      },
      { status: 429, headers: { "Retry-After": String(limit.retryAfter) } },
    );
  if (!RESEND_API_KEY || !CONTACT_FROM_EMAIL)
    return NextResponse.json(
      {
        message: `Message delivery is not enabled yet. Please email ${contactEmail} or book a meeting.`,
      },
      { status: 503 },
    );
  try {
    await deliverInquiry(parsed.data, {
      apiKey: RESEND_API_KEY,
      from: CONTACT_FROM_EMAIL,
      to: CONTACT_TO_EMAIL || contactEmail,
    });
    return NextResponse.json({
      message: "Thank you. Your inquiry has been sent to Quite Logic.",
    });
  } catch {
    return NextResponse.json(
      {
        message:
          "We couldn’t deliver your inquiry right now. Please try again in a moment.",
      },
      { status: 502 },
    );
  }
}
