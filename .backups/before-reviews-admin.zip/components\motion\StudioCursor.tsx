"use client";
import { useEffect, useState, useSyncExternalStore } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";
import { useMotionPreference } from "@/hooks/useMotionPreference";

const query = "(min-width: 901px) and (hover: hover) and (pointer: fine)";
const snapshot = () =>
  matchMedia(query).matches && navigator.maxTouchPoints === 0;
const serverSnapshot = () => false;
function subscribe(change: () => void) {
  const media = matchMedia(query);
  media.addEventListener("change", change);
  return () => media.removeEventListener("change", change);
}

export default function StudioCursor() {
  const eligible = useSyncExternalStore(subscribe, snapshot, serverSnapshot);
  const reduced = useMotionPreference();
  const enabled = eligible && !reduced;
  const x = useMotionValue(-100),
    y = useMotionValue(-100);
  const sx = useSpring(x, { stiffness: 650, damping: 42, mass: 0.5 });
  const sy = useSpring(y, { stiffness: 650, damping: 42, mass: 0.5 });
  const [kind, setKind] = useState("");
  const [shown, setShown] = useState(false);
  useEffect(() => {
    if (!enabled) return;
    let visible = false;
    const hide = () => {
      visible = false;
      setShown(false);
      setKind("");
      delete document.documentElement.dataset.studioCursor;
    };
    const classify = (target: Element) => {
      const link = target.closest("a");
      const label = target
        .closest("[data-cursor]")
        ?.getAttribute("data-cursor");
      setKind(
        label === "VIEW" || label === "OPEN"
          ? label
          : link?.querySelector("img")
            ? "OPEN"
            : target.closest("a,button,[role=button],[role=combobox]")
              ? "interactive"
              : "",
      );
    };
    const move = (event: PointerEvent) => {
      if (
        event.pointerType !== "mouse" ||
        !(event.target instanceof Element) ||
        event.target.closest("input,textarea,iframe,[contenteditable=true]")
      ) {
        hide();
        return;
      }
      x.set(event.clientX);
      y.set(event.clientY);
      if (!visible) {
        sx.jump(event.clientX);
        sy.jump(event.clientY);
      }
      visible = true;
      setShown(true);
      document.documentElement.dataset.studioCursor = "active";
      classify(event.target);
    };
    const over = (event: PointerEvent) => {
      if (event.target instanceof HTMLIFrameElement) {
        hide();
        return;
      }
      if (visible && event.target instanceof Element) classify(event.target);
    };
    const visibility = () => {
      if (document.hidden) hide();
    };
    const scroll = () => {
      if (!visible) return;
      const target = document.elementFromPoint(x.get(), y.get());
      if (target) classify(target);
    };
    document.addEventListener("pointermove", move, { passive: true });
    document.addEventListener("pointerover", over, { passive: true });
    document.addEventListener("pointerleave", hide);
    document.addEventListener("visibilitychange", visibility);
    window.addEventListener("blur", hide);
    window.addEventListener("scroll", scroll, { passive: true });
    return () => {
      document.removeEventListener("pointermove", move);
      document.removeEventListener("pointerover", over);
      document.removeEventListener("pointerleave", hide);
      document.removeEventListener("visibilitychange", visibility);
      window.removeEventListener("blur", hide);
      window.removeEventListener("scroll", scroll);
      hide();
    };
  }, [enabled, x, y, sx, sy]);
  if (!enabled) return null;
  const label = kind === "VIEW" || kind === "OPEN" ? kind : "";
  return (
    <motion.div
      aria-hidden="true"
      className="studio-cursor"
      data-state={kind || "normal"}
      style={{ x: sx, y: sy, opacity: shown ? 1 : 0 }}
    >
      <motion.span
        className="cursor-ring"
        animate={{ scale: label ? 1.7 : kind ? 1.45 : 1 }}
        transition={{ type: "spring", stiffness: 500, damping: 28, mass: 0.6 }}
      />
      <motion.span
        className="cursor-dot"
        animate={{ opacity: label ? 0 : 1, scale: kind ? 0.8 : 1 }}
        transition={{ duration: 0.18 }}
      />
      <span className="cursor-label">{label}</span>
    </motion.div>
  );
}
