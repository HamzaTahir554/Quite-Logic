import { createHash } from "node:crypto";

// Bounded, per-process protection. Use a shared edge limit when scaling.
export function createInquiryLimiter() {
  const windowMs = 15 * 60 * 1000;
  const recipients = new Map<string, number>();
  let total = 0,
    expires = 0;
  return (email: string, now = Date.now()) => {
    if (now >= expires) {
      total = 0;
      expires = now + windowMs;
      recipients.clear();
    }
    const key = createHash("sha256")
      .update(email.trim().toLowerCase())
      .digest("hex");
    const count = recipients.get(key) ?? 0;
    if (total >= 60 || count >= 5)
      return {
        allowed: false,
        retryAfter: Math.max(1, Math.ceil((expires - now) / 1000)),
      };
    recipients.set(key, count + 1);
    total++;
    return { allowed: true, retryAfter: 0 };
  };
}
export const allowInquiry = createInquiryLimiter();
