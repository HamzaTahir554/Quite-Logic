import { NextResponse } from "next/server";
import { contactSchema } from "@/lib/contact";
export const runtime = "nodejs";
export async function POST(request: Request) {
  const origin = request.headers.get("origin");
  if (
    origin &&
    origin !== new URL(request.url).origin &&
    origin !== process.env.NEXT_PUBLIC_SITE_URL?.replace(/\/$/, "")
  )
    return NextResponse.json(
      { message: "This request is not allowed." },
      { status: 403 },
    );
  if (!request.headers.get("content-type")?.includes("application/json"))
    return NextResponse.json(
      { message: "Please submit a JSON inquiry." },
      { status: 415 },
    );
  if (Number(request.headers.get("content-length")) > 16000)
    return NextResponse.json(
      { message: "Your inquiry is too large." },
      { status: 413 },
    );
  let data: unknown;
  try {
    const body = await request.text();
    if (body.length > 16000)
      return NextResponse.json(
        { message: "Your inquiry is too large." },
        { status: 413 },
      );
    data = JSON.parse(body);
  } catch {
    return NextResponse.json(
      { message: "Please check your inquiry and try again." },
      { status: 400 },
    );
  }
  const parsed = contactSchema.safeParse(data);
  if (!parsed.success)
    return NextResponse.json(
      { message: "Please check the form fields and try again." },
      { status: 400 },
    );
  const { RESEND_API_KEY, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL } = process.env;
  if (!RESEND_API_KEY || !CONTACT_TO_EMAIL || !CONTACT_FROM_EMAIL)
    return NextResponse.json(
      {
        message:
          "Project inquiries are not enabled yet. Please try again once the studio has configured message delivery.",
      },
      { status: 503 },
    );
  const { name, email, company, phone, projectType, budget, description } =
    parsed.data;
  try {
    const response = await fetch("https://api.resend.com/emails", {
      method: "POST",
      signal: AbortSignal.timeout(10000),
      headers: {
        Authorization: `Bearer ${RESEND_API_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: CONTACT_FROM_EMAIL,
        to: [CONTACT_TO_EMAIL],
        reply_to: email,
        subject: `Quite Logic inquiry: ${projectType}`,
        text: `Name: ${name}\nEmail: ${email}\nCompany: ${company}\nPhone: ${phone || "Not provided"}\nType: ${projectType}\nBudget: ${budget}\n\n${description}`,
      }),
    });
    if (!response.ok) throw new Error("Delivery failed");
    return NextResponse.json({
      message: "Thank you. Your inquiry has been sent to Quite Logic.",
    });
  } catch {
    return NextResponse.json(
      {
        message:
          "We couldn’t deliver your inquiry right now. Please try again in a moment.",
      },
      { status: 502 },
    );
  }
}
