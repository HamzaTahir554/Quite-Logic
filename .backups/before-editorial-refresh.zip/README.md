# Quite Logic

Next.js App Router website built with TypeScript, MUI, React Three Fiber, Three.js, Drei, Framer Motion, and GSAP. The supplied `Demo/` and `snapshots/` references are preserved.

## Development

Requires Node.js 24 and npm.

```powershell
npm.cmd ci
Copy-Item .env.example .env.local
npm.cmd run dev
```

Open http://localhost:3000. On Windows, `npm.cmd` avoids the PowerShell script execution policy restriction.

## Production

```powershell
npm.cmd run build
npm.cmd start
```

Use a host supporting Next.js 16 with Node.js 24, such as Vercel or a Node server. This application includes a server-side contact endpoint and dynamic social images. It is not a static-only export. The first build needs network access to download Manrope through `next/font`; the generated site self-hosts the font.

Before public launch:

- Set `NEXT_PUBLIC_SITE_URL` to the final HTTPS domain before building. It powers canonical URLs, structured data, social metadata, and the sitemap. Development falls back to localhost.
- Set `RESEND_API_KEY`, `CONTACT_FROM_EMAIL` (a verified sender), and `CONTACT_TO_EMAIL` in the hosting secret environment to enable inquiry delivery.
- Configure rate limiting and bot protection at the hosting edge. The contact endpoint includes shared client/server validation, origin checks, payload limits, a honeypot, and provider timeouts. An in-memory rate limit would not reliably protect multiple server instances.
- Replace the explicitly labeled illustrative portfolio concepts with authorized client work when available. No customer results or testimonials are fabricated.
- Replace the visibly marked social placeholders with real company profile links.
- Review the privacy information needed for your business before collecting inquiries publicly.

Without mail configuration, the API returns 503 and the form explains delivery is unavailable. It does not pretend to send or store messages. Failed submissions preserve the entered values. Real email delivery requires configuration and a provider smoke test.

## Architecture

- `app/`: homepage, services, about, work/process, portfolio, contact, concept detail pages, SEO endpoints, and branded loading/error/404 states.
- `components/`: shared navigation, footer, page sections, UI, SEO, and dynamically loaded hero scene.
- `data/content.ts`: editable navigation, services, project concepts, and process copy.
- `theme/theme.ts` and `app/globals.css`: brand tokens, MUI customization, layout, motion, and responsive design.
- `lib/contact.ts`: shared form schema and options.
- `app/api/contact/route.ts`: Resend delivery adapter; replace here for another mail provider or CRM.
- `public/logo/`: original supplied branding; `public/projects/`: local concept artwork.

The shared design system uses Smoky Gray `#4B5560` for the page, Slate `#303944` for contrast, Card Gray `#596572` for surfaces, Blue `#2F80FE` for accents, and Off White `#F0F1F8` for primary text. The shared brand component gives Quite and Logic their distinct colors.

The homepage and services page share a six-faced service cube: Web, Apps, AI Automation, AI Vision, Custom Software, and Explore All. Desktop uses a lazy-loaded React Three Fiber scene with generated local textures, capped DPR, quaternion snapping, scroll selection, raycast face selection, drag, hover, and deliberate autoplay. Tablet/mobile use a lightweight CSS cube with horizontal touch swipes and native vertical scrolling. Accessible buttons and previous/next controls work in both renderers. Reduced motion disables autoplay, WebGL, pointer tilt, and transition animation without hiding service content. Unsupported WebGL and limited device capabilities retain the CSS experience. MUI Drawer provides mobile focus management and Escape dismissal.

`components/motion/` contains magnetic CTAs, the global cursor/progress/navigation effects, distinct page-banner treatments, and GSAP service scroll effects. Scene rendering and service autoplay pause outside the nearby viewport and in inactive tabs. Continuous decorative motion is scoped to visible sections and pauses in inactive tabs. Animation instances, textures, geometry, listeners, observers, timers, and GSAP contexts have cleanup paths. `app/studio.css` and `app/interaction.css` style the shared pages and interactions; `app/hero.css` implements the centered home hero and branding. `app/atlas-motion.css` styles project visuals, banners, and the Atlas showcase using shared gray tokens. `app/service-cube.css` styles the signature cube, lighter panels, and animated slate footer. Scrolling remains native.

The cube follows the mouse on desktop, including its CSS fallback. Mobile uses passive face rotation, horizontal swipes, and buttons. The site does not access physical motion sensors or request motion permissions. Live reduced-motion preferences stop scene animation and autoplay without a reload.

See [the design system report](qa/DESIGN-SYSTEM-REPORT.md) for the underlying visuals. Capture the signature interaction with `node qa/capture-cube.mjs`; run `node qa/audit-design.mjs` for a short desktop frame/CLS sample. These default to port 3100 and accept `E2E_BASE_URL`. Atlas / Cloud retains its shared illustrative terminal showcase on the homepage, portfolio, and `/portfolio/atlas-cloud` detail page. The previous project URL permanently redirects to the replacement. The earlier [Atlas report](qa/ATLAS-REPORT.md) records that feature's implementation.

## Verification

```powershell
npm.cmd run typecheck
npx.cmd playwright install chromium
npm.cmd run build
npm.cmd run test:e2e
```

Nineteen browser tests cover the palette, six-face cube, desktop mouse input, mobile touch and native scrolling, absence of sensor access and permission controls, live reduced-motion preferences, Atlas, navigation, portfolio, contact, SEO, banner, branding, and layout checks. All core routes are checked at seven widths (320–1440px). Screenshots are captured in `qa/screenshots/`. A mocked successful contact response tests the UI only, not real email delivery.

For an isolated local test server, run `$env:E2E_BASE_URL='http://localhost:3100'; npm.cmd run test:e2e`. Set the final site origin through `NEXT_PUBLIC_SITE_URL` for deployment; the test server port does not alter canonical configuration.
