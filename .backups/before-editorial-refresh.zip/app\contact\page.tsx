import { PageHero } from "@/components/ui/Elements";
import ContactForm from "@/components/sections/ContactForm";
import StructuredData from "@/components/seo/StructuredData";
import { pageMetadata } from "@/lib/seo";
export const metadata = pageMetadata(
  "Start a Project",
  "Tell Quite Logic about your website, mobile application, AI automation, computer vision, or custom software project.",
  "/contact",
);
export default function ContactPage() {
  return (
    <>
      <StructuredData path="/contact" name="Contact" />
      <PageHero
        variant="contact"
        label="Start a conversation"
        title="Let’s build"
        accent="something useful."
        description="A new idea, an existing product, or a process that could work better. Tell us what you have in mind."
      />
      <section className="container contact-layout">
        <aside>
          <span className="overline">A thoughtful first step</span>
          <h2>
            Big ideas start
            <br />
            with a simple hello.
          </h2>
          <p>
            You don’t need a finished brief. A few details about the problem,
            your goals, and where you are today are enough to begin.
          </p>
          <div className="contact-expectations">
            <h3>What happens next?</h3>
            <ol>
              <li>We review your project and the context.</li>
              <li>We clarify the questions that matter.</li>
              <li>We agree on a useful next step together.</li>
            </ol>
          </div>
          <span className="small muted">
            No pitch deck required. Just a good conversation.
          </span>
        </aside>
        <ContactForm />
      </section>
    </>
  );
}
