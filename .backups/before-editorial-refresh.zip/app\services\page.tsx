import { services } from "@/data/content";
import { PageHero, CTA } from "@/components/ui/Elements";
import Reveal from "@/components/ui/Reveal";
import StructuredData from "@/components/seo/StructuredData";
import { pageMetadata } from "@/lib/seo";
import ServiceExplorer from "@/components/sections/ServiceExplorer";
import ServiceScroll from "@/components/motion/ServiceScroll";
export const metadata = pageMetadata(
  "Software Development Services",
  "Explore Quite Logic’s web, mobile, AI automation, computer vision, and custom software development services.",
  "/services",
);
export default function ServicesPage() {
  return (
    <>
      <StructuredData path="/services" name="Services" />
      <PageHero
        variant="services"
        label="Our expertise"
        title="Engineering digital experiences"
        accent="that make complex things feel simple."
        description="The right technology, thoughtfully applied. From your first prototype to the systems behind your business."
      />
      <ServiceExplorer />
      <ServiceScroll>
        <div className="container service-details">
          {services.map((s, i) => (
            <Reveal key={s.slug}>
              <section className="service-detail" id={s.slug}>
                <div className="service-detail-visual" aria-hidden="true">
                  <span className="technical-label">DISCIPLINE / 0{i + 1}</span>
                  <div className={`service-sculpture sculpture-${i}`}>
                    <span>{s.icon}</span>
                    <i />
                    <i />
                  </div>
                  <span className="technical-label">
                    CLARITY THROUGH ENGINEERING
                  </span>
                </div>
                <div className="service-detail-copy">
                  <span className="overline">
                    0{i + 1} / {s.short}
                  </span>
                  <h2>{s.name}</h2>
                  <p>{s.details}</p>
                  <ul className="capabilities">
                    {s.capabilities.map((c) => (
                      <li key={c}>{c}</li>
                    ))}
                  </ul>
                  <a
                    className="text-link"
                    href={`/contact?service=${encodeURIComponent(s.name)}`}
                  >
                    Let’s talk {s.short.toLowerCase()} ↗
                  </a>
                </div>
              </section>
            </Reveal>
          ))}
        </div>
      </ServiceScroll>
      <CTA />
    </>
  );
}
