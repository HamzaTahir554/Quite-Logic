"use client";
import Link from "next/link";
import {
  motion,
  useMotionValue,
  useSpring,
  useReducedMotion,
} from "framer-motion";
import type { PointerEvent, ReactNode } from "react";
const MotionLink = motion.create(Link);
export default function MagneticLink({
  href,
  children,
  secondary = false,
  className = "",
}: {
  href: string;
  children: ReactNode;
  secondary?: boolean;
  className?: string;
}) {
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 220, damping: 17 });
  const sy = useSpring(y, { stiffness: 220, damping: 17 });
  const reduced = useReducedMotion();
  function move(event: PointerEvent<HTMLAnchorElement>) {
    if (reduced || event.pointerType !== "mouse") return;
    const rect = event.currentTarget.getBoundingClientRect();
    x.set((event.clientX - rect.left - rect.width / 2) * 0.13);
    y.set((event.clientY - rect.top - rect.height / 2) * 0.18);
    event.currentTarget.style.setProperty(
      "--glow-x",
      `${event.clientX - rect.left}px`,
    );
    event.currentTarget.style.setProperty(
      "--glow-y",
      `${event.clientY - rect.top}px`,
    );
  }
  return (
    <MotionLink
      href={href}
      className={`button magnetic ${secondary ? "secondary" : "primary"} ${className}`}
      style={{ x: sx, y: sy }}
      onPointerMove={move}
      onPointerLeave={() => {
        x.set(0);
        y.set(0);
      }}
      onBlur={() => {
        x.set(0);
        y.set(0);
      }}
      whileTap={reduced ? {} : { scale: 0.97 }}
    >
      <motion.span className="button-label" style={{ x: sx, y: sy }}>
        {children}
      </motion.span>
      <span className="button-arrow" aria-hidden="true">
        ↗
      </span>
    </MotionLink>
  );
}
