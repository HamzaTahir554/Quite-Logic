"use client";
import Image from "next/image";
import dynamic from "next/dynamic";
import {
  motion,
  useMotionValue,
  useReducedMotion,
  useSpring,
} from "framer-motion";
import { Action } from "@/components/ui/Elements";
import SceneBoundary from "@/components/three/SceneBoundary";
import { useSceneActivity } from "@/hooks/useSceneActivity";
import type { PointerEvent } from "react";
const HeroScene = dynamic(() => import("@/components/three/HeroScene"), {
  ssr: false,
  loading: () => null,
});

export default function Hero() {
  const { ref, enabled, active } = useSceneActivity();
  const reduced = useReducedMotion();
  const px = useMotionValue(0);
  const py = useMotionValue(0);
  const x = useSpring(px, { stiffness: 45, damping: 24 });
  const y = useSpring(py, { stiffness: 45, damping: 24 });
  function pointer(event: PointerEvent<HTMLElement>) {
    if (reduced || event.pointerType !== "mouse") return;
    const rect = event.currentTarget.getBoundingClientRect();
    px.set(((event.clientX - rect.left) / rect.width - 0.5) * 14);
    py.set(((event.clientY - rect.top) / rect.height - 0.5) * 10);
  }
  return (
    <section
      className="hero reference-hero"
      data-motion-active={active}
      aria-label="Quite Logic software studio"
      onPointerMove={pointer}
      onPointerLeave={() => {
        px.set(0);
        py.set(0);
      }}
    >
      <div className="hero-atmosphere" ref={ref} aria-hidden="true">
        <div className="atmosphere-grid" />
        <motion.div className="atmosphere-orbits" style={{ x, y }}>
          <span />
          <span />
          <span />
          <Image
            src="/logo/icon.png"
            alt=""
            width={560}
            height={560}
            className="atmosphere-emblem"
            priority
          />
        </motion.div>
        <div className="hero-scene">
          {enabled && (
            <SceneBoundary>
              <HeroScene active={active} />
            </SceneBoundary>
          )}
        </div>
        <div className="atmosphere-glow glow-left" />
        <div className="atmosphere-glow glow-right" />
      </div>
      <div className="hero-copy">
        <span className="eyebrow hero-eyebrow">
          <i />
          Digital products, AI &amp; automation
        </span>
        <h1>
          <span className="hero-title-line">
            <span>Software that</span>
          </span>{" "}
          <span className="hero-title-line">
            <span>feels calm.</span>
          </span>{" "}
          <span className="hero-title-line">
            <span>
              Built to move <em>fast.</em>
            </span>
          </span>
        </h1>
        <p className="hero-description">
          We design and build high-performance digital products, intelligent
          automation and AI-powered systems for modern businesses.
        </p>
        <div className="hero-actions">
          <Action href="/contact">Start a Project</Action>
          <Action href="/portfolio" secondary>
            Explore Our Work
          </Action>
        </div>
        <div className="hero-disciplines" aria-label="Our disciplines">
          <span>Web</span>
          <i />
          <span>Apps</span>
          <i />
          <span>AI Automation</span>
          <i />
          <span>AI Vision</span>
        </div>
      </div>
      <a
        href="#services"
        className="hero-scroll"
        aria-label="Explore our services"
      >
        <span>Explore the studio</span>
        <span aria-hidden="true">↓</span>
      </a>
    </section>
  );
}
