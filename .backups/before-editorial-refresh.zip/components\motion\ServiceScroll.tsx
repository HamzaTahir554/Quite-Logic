"use client";
import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
export default function ServiceScroll({
  children,
}: {
  children: React.ReactNode;
}) {
  const root = useRef<HTMLDivElement>(null);
  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger);
    const media = gsap.matchMedia();
    media.add(
      {
        motion: "(prefers-reduced-motion: no-preference)",
        desktop: "(min-width: 900px)",
      },
      (context) => {
        if (!context.conditions?.motion) return;
        const wide = context.conditions.desktop;
        const sections =
          root.current?.querySelectorAll<HTMLElement>(".service-detail");
        sections?.forEach((section, i) => {
          const sculpture = section.querySelector(".service-sculpture");
          const angles = [-18, 12, -25, 18, -12];
          gsap.fromTo(
            sculpture,
            { rotation: angles[i], y: wide ? 45 : 15, scale: 0.85 },
            {
              rotation: -angles[i] * 0.4,
              y: wide ? -35 : -10,
              scale: 1.05,
              ease: "none",
              scrollTrigger: {
                trigger: section,
                start: "top 90%",
                end: "bottom 15%",
                scrub: 1,
              },
            },
          );
          gsap.fromTo(
            section.querySelectorAll(".capabilities li"),
            { y: 18, opacity: 0.25 },
            {
              y: 0,
              opacity: 1,
              stagger: 0.07,
              duration: 0.6,
              scrollTrigger: {
                trigger: section,
                start: "top 65%",
                toggleActions: "play none none reverse",
              },
            },
          );
          if (wide)
            gsap.fromTo(
              section,
              { clipPath: "inset(0 2% 0 2% round 32px)" },
              {
                clipPath: "inset(0 0% 0 0% round 32px)",
                scrollTrigger: {
                  trigger: section,
                  start: "top bottom",
                  end: "top 35%",
                  scrub: 0.7,
                },
              },
            );
        });
      },
      root,
    );
    return () => media.revert();
  }, []);
  return (
    <div className="service-scroll" ref={root}>
      {children}
    </div>
  );
}
